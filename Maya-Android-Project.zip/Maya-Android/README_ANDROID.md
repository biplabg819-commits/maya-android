# Maya AI — Android Edition

Native Android rewrite of the supplied Maya AI 1.2 macOS project.

## Included
- Maya wake phrase while the app is open
- Android SpeechRecognizer voice input
- Android Text-to-Speech responses
- YouTube / Google search
- Play song via YouTube search
- Open Chrome / WhatsApp / VS Code when installed, with browser fallback
- Android folder picker
- Ollama AI chat through a configurable HTTP endpoint
- Original Maya animation GIF

## Important
The original project used macOS-only `open`, `say`, `mdfind`, PyAutoGUI, PyObjC and desktop microphone APIs. Those were replaced or removed.

The current screenshot command intentionally does not silently capture the screen. Android requires user-approved screen-capture permission through MediaProjection; a production version can add that flow.

For Ollama on a physical phone, set the URL in **AI Settings** to the computer's LAN address, e.g. `http://192.168.1.10:11434`, and configure Ollama to accept LAN connections/firewall access. `10.0.2.2` is the Android emulator's host alias.

## Build
Open this folder in Android Studio and let it sync Gradle, then Build > Build APK(s).


## Build-ready package

This package now includes:
- `BUILD_APK.md` with phone-friendly APK build instructions
- `.github/workflows/build-apk.yml` for a GitHub cloud build
- `FirebaseConfig.java` containing the requested Realtime Database URL

The workflow produces `app-debug.apk` as a downloadable GitHub Actions artifact.
