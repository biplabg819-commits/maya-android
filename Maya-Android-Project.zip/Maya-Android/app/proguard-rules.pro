# Maya Android: keep default rules for now.
