package com.maya.ai;

/**
 * Project configuration for Maya Android.
 * This is a database URL, not a secret key.
 */
public final class FirebaseConfig {
    private FirebaseConfig() {}

    public static final String REALTIME_DATABASE_URL =
            "https://routine-tracker-52455-default-rtdb.firebaseio.com/";
}
