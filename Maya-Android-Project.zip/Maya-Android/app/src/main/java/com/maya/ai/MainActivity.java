package com.maya.ai;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    TextView status, log; SpeechRecognizer recognizer; TextToSpeech tts; boolean waitingForCommand=false; boolean listening=false;
    ExecutorService executor=Executors.newSingleThreadExecutor(); String ollamaUrl="http://10.0.2.2:11434"; String ollamaModel="llama3";
    final int MIC=41;

    @Override public void onCreate(Bundle b){ super.onCreate(b); setContentView(com.maya.ai.R.layout.activity_main);
        status=findViewById(R.id.status); log=findViewById(R.id.log); Button listen=findViewById(R.id.listenButton); Button settings=findViewById(R.id.settingsButton);
        tts=new TextToSpeech(this, s->{ if(s==TextToSpeech.SUCCESS) tts.setLanguage(Locale.US); });
        if(android.os.Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},MIC);
        setupRecognizer();
        listen.setOnClickListener(v->listenNow()); settings.setOnClickListener(v->showAISettings());
        speak("Maya is activated");
    }
    void setupRecognizer(){ recognizer=SpeechRecognizer.createSpeechRecognizer(this); recognizer.setRecognitionListener(new RecognitionListener(){
        public void onReadyForSpeech(Bundle p){ listening=true; status.setText("Listening..."); }
        public void onBeginningOfSpeech(){ }
        public void onRmsChanged(float r){} public void onBufferReceived(byte[] b){} public void onEndOfSpeech(){ listening=false; }
        public void onError(int e){ listening=false; status.setText("Tap the button and speak again"); }
        public void onResults(Bundle b){ listening=false; ArrayList<String> a=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION); if(a==null||a.isEmpty()) return; String text=a.get(0); add("You: "+text); if(waitingForCommand){waitingForCommand=false; processCommand(text);} else if(text.toLowerCase(Locale.US).contains("maya")){ speak("Yes boss"); waitingForCommand=true; status.setText("Say your command..."); new android.os.Handler().postDelayed(()->listenNow(),700); } else { status.setText("Say Maya first"); } }
        public void onPartialResults(Bundle b){} public void onEvent(int t,Bundle p){}
    }); }
    void listenNow(){ if(android.os.Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},MIC);return;} Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"en-IN"); i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,false); recognizer.startListening(i); }
    void speak(String s){ add("Maya: "+s); status.setText(s); if(tts!=null) tts.speak(s,TextToSpeech.QUEUE_FLUSH,null,"maya"); }
    void add(String s){ runOnUiThread(()->{log.append(s+"\n\n"); ((ScrollView)log.getParent()).post(()->((ScrollView)log.getParent()).fullScroll(View.FOCUS_DOWN));}); }
    void processCommand(String raw){ String c=raw.toLowerCase(Locale.US).trim();
        try{
            if(c.contains("introduce yourself")||c.contains("who are you")||c.contains("tell me about yourself")){speak("Hello! I am Maya, your Android voice assistant. I am ready to help, boss.");}
            else if(c.contains("open youtube")){speak("Opening YouTube"); openUrl("https://youtube.com");}
            else if(c.contains("open chrome")){speak("Opening Chrome"); launchPackage("com.android.chrome","https://google.com");}
            else if(c.contains("open whatsapp")){speak("Opening WhatsApp"); launchPackage("com.whatsapp","https://web.whatsapp.com");}
            else if(c.contains("open visual studio code")||c.contains("open vs code")){speak("Opening Visual Studio Code"); launchPackage("com.microsoft.vscode","https://vscode.dev");}
            else if(c.startsWith("play ")){String q=raw.substring(5).trim(); speak("Playing "+q+" on YouTube"); openUrl("https://www.youtube.com/results?search_query="+URLEncoder.encode(q,"UTF-8"));}
            else if(c.startsWith("search google for")){String q=raw.substring(17).trim(); speak("Searching Google"); openUrl("https://www.google.com/search?q="+URLEncoder.encode(q,"UTF-8"));}
            else if(c.startsWith("search youtube for")){String q=raw.substring(19).trim(); speak("Searching YouTube"); openUrl("https://www.youtube.com/results?search_query="+URLEncoder.encode(q,"UTF-8"));}
            else if(c.contains("open folder")){speak("Choose the folder in the Android file picker"); startActivity(new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE));}
            else if(c.contains("screenshot")){speak("Android screenshot capture needs system screen-capture permission. Use the phone screenshot shortcut for now.");}
            else if(c.contains("stop maya")){speak("Goodbye boss");}
            else {speak("Thinking boss"); askAI(raw);}
        }catch(Exception e){speak("Sorry boss, I could not complete that command.");}
    }
    void launchPackage(String pkg,String fallback){try{Intent i=getPackageManager().getLaunchIntentForPackage(pkg); if(i!=null){startActivity(i);return;}}catch(Exception ignored){} openUrl(fallback);}
    void openUrl(String u){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(u)));}catch(Exception e){Toast.makeText(this,"No browser available",Toast.LENGTH_SHORT).show();}}
    void askAI(String prompt){ executor.execute(()->{try{URL url=new URL(ollamaUrl+"/api/chat"); HttpURLConnection con=(HttpURLConnection)url.openConnection(); con.setRequestMethod("POST"); con.setConnectTimeout(8000); con.setReadTimeout(30000); con.setDoOutput(true); con.setRequestProperty("Content-Type","application/json"); JSONObject body=new JSONObject(); body.put("model",ollamaModel); body.put("stream",false); JSONArray msgs=new JSONArray(); JSONObject m=new JSONObject(); m.put("role","user"); m.put("content",prompt); msgs.put(m); body.put("messages",msgs); try(OutputStream os=con.getOutputStream()){os.write(body.toString().getBytes(StandardCharsets.UTF_8));} BufferedReader br=new BufferedReader(new InputStreamReader(con.getInputStream())); StringBuilder sb=new StringBuilder(); String line; while((line=br.readLine())!=null)sb.append(line); JSONObject out=new JSONObject(sb.toString()); String reply=out.getJSONObject("message").getString("content"); runOnUiThread(()->speak(reply));}catch(Exception e){runOnUiThread(()->speak("AI is not responding. Check Ollama URL and make sure the phone can reach the Ollama computer."));}});}
    void showAISettings(){ final EditText url=new EditText(this); url.setHint("Ollama URL, e.g. http://192.168.1.10:11434"); url.setText(ollamaUrl); final EditText model=new EditText(this); model.setHint("Model"); model.setText(ollamaModel); LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(40,10,40,10); box.addView(url); box.addView(model); new android.app.AlertDialog.Builder(this).setTitle("Maya AI Settings").setView(box).setPositiveButton("Save",(d,w)->{ollamaUrl=url.getText().toString().trim(); ollamaModel=model.getText().toString().trim();}).setNegativeButton("Cancel",null).show(); }
    @Override protected void onDestroy(){if(recognizer!=null)recognizer.destroy();if(tts!=null)tts.shutdown();executor.shutdownNow();super.onDestroy();}
}
